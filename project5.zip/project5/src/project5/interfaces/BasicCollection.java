package project5.interfaces;

public interface BasicCollection<E> {

	public int size(); 
	
	public boolean isEmpty(); 

}

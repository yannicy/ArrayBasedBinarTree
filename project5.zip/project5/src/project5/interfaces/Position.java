package project5.interfaces;

public interface Position<E> {
	
	public E element();

}

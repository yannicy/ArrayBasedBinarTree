package project5.exceptions;

@SuppressWarnings("serial")
public class UnemptyTreeException extends RuntimeException {

}

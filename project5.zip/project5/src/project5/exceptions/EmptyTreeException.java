package project5.exceptions;

@SuppressWarnings("serial")
public class EmptyTreeException extends RuntimeException {

	public EmptyTreeException() {
		
	}
	
}

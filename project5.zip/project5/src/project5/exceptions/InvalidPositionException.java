package project5.exceptions;

@SuppressWarnings("serial")
public class InvalidPositionException extends RuntimeException {

}
